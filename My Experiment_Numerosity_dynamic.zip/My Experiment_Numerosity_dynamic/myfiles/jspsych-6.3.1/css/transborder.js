.transborder{
  /* essential styles, 
   * all that's needed to create the effect */
  border: solid .5em #be4c39;
  padding: .5em;
  background: #e18728 content-box;
  
  /* non-essential, just to prettify the thing */
  margin: 0 auto;
  width: 5em; height: 3em;
  color: white;
  font: 700 2em/3 comic sans ms, verdana, sans serif;
  text-align: center;
}