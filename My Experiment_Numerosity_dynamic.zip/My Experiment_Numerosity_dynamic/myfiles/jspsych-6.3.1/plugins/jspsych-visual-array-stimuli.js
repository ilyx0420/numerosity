/**
 *
 * jspsych-visual-search-circle
 * Josh de Leeuw
 *
 * display a set of objects, with or without a target, equidistant from fixation
 * subject responds to whether or not the target is present
 *
 * based on code written for psychtoolbox by Ben Motz
 *
 * documentation: docs.jspsych.org
 *
 **/

jsPsych.plugins["visual-array-stimuli"] = (function() {

  var plugin = {};

  jsPsych.pluginAPI.registerPreload('visual-array-stimuli', 'target', 'image');
  jsPsych.pluginAPI.registerPreload('visual-array-stimuli', 'foil', 'image');
  jsPsych.pluginAPI.registerPreload('visual-array-stimuli', 'fixation_image', 'image');

  plugin.info = {
    name: 'visual-array-stimuli',
    description: '',
    parameters: {
      set_size: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Set size1',
        default: undefined,
        description: 'How many items should be displayed?'
      },

      set_size_r: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Set size2',
        default: undefined,
        description: 'How many items should be displayed?'
      },

      target_size: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Target size',
        array: true,
        default: [60, 60],
        description: 'Two element array indicating the height and width of the search array element images.'
      },
      fixation_size: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Fixation size',
        array: true,
        default: [20, 20],
        description: 'Two element array indicating the height and width of the fixation image.'
      },
      circle_diameter: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Circle diameter1',
        default: 500,
        description: 'The diameter of the search array circle in pixels.'
      },
      trial_duration: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Trial duration',
        default: 250,
        description: 'The maximum duration to wait for a response.'
      },
      //
      //corls: {
        //type: jsPsych.plugins.parameterType.INT,
        //pretty_name: 'colrs',
        //default: ["blue", "green"],
        //description: 'The maximum duration to wait for a response.'
      //},
    }
  }


  //function getRandomIntInclusive(min, max) {
  //var min = Math.ceil(10);
  //var max = Math.floor(25);
  //var randv =  Math.floor(Math.random() * (25 - 10 + 1) + 10); //The maximum is inclusive and the minimum is inclusive

//}

//var aaa = [10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25];
//var randv = jsPsych.randomization.sampleWithoutReplacement(aaa, 1);



plugin.trial = function(display_element, trial) {


// circle params
var diam = trial.circle_diameter; // pixels
var radi = diam / 2;
//var paper_size = diam + trial.target_size[0];

//var paper_size = 390;
var paper_size = 390;
var paper_width = paper_size * 1.3 ; 

// stimuli width, height
var stimh = trial.target_size[0];
var stimw = trial.target_size[1];
var hstimh = stimh / 2;
var hstimw = stimw / 2;
var number_stim = trial.set_size; // IMPORTANT
var number_stim_r = trial.set_size_r;
 
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//////////////// ----------- FIX PAPER POSITION --------------- ///////////////

var bordersize = 50; 
var pos_paper_top = 0;  
var pos_paper_left = 0; 
var imagebetweengap = -30;



///// ------ DECIDE WHICH CASE [NO OCCULDE / BOTH OCCLUDE / HALF-HALF] ---- /////

var randord = Math.random();

if (randord < 1/3){
    var randordsub = Math.random();
    if (randordsub < 0.5){
       var disord = "hybrid-occludright";
        }else{
        var disord = "hybrid-occludleft";
        }
}else if(randord >= 1/3 && randord < 2/3){
      var disord = "both-no";
}else{
   var disord = "both-occlude";
}

var disord = "hybrid-occludleft";


/////// ------- DECIDE WHICH OCCLUDE MASK TO USE------------ //////

var randmask = Math.random();

if (randmask < 1/4){
    var bubccc = 1;
  }else if (randmask >= 1/4 && randmask < 2/4){
    var bubccc = 2;
  }
else if (randmask >= 2/4 && randmask < 3/4){
    var bubccc = 3;
}else if (randmask >= 3/4 && randmask <= 1){
    var bubccc = 4;
}
var bubccc =4;



/////// ---------- FIX POSITIONS OF TWO IMAGES ---------- //////
if (disord == "hybrid-occludleft"){
//////----------    OCCLUSION RIGHT - NO OCCLUSION LEFT    --------------//////
var pos_leftpaper_top =  0  ;  // fix, dont change
var pos_leftpaper_left = 0 - paper_width * 0.5 - imagebetweengap;// fix, dont change
var pos_leftpaper_top_small = pos_leftpaper_top + bordersize;
var pos_leftpaper_left_small = pos_leftpaper_left + bordersize;


var pos_rightpaper_top = 0 ; // fix, dont change
var pos_rightpaper_left = paper_width * 0.5 + imagebetweengap; // fix, dont change

var masright = pos_rightpaper_left + 1 * bordersize; // fix, dont change
var mastop = pos_rightpaper_top +  1 * bordersize; 

var maskwidth = paper_width - 2 * bordersize;
var maskheight = paper_size - 2 * bordersize;

var masgrayleft = pos_rightpaper_left + bordersize;
var masgraytop = pos_rightpaper_top + bordersize;

var graywidth = paper_width + bordersize ;
var grayheight = paper_size + bordersize ; 
}else{ /// hybrid-occludright && both occlude && both no
var pos_leftpaper_top =  0  ;  // fix, dont change
var pos_leftpaper_left = 0 + paper_width * 0.5 + imagebetweengap;// fix, dont change
var pos_leftpaper_top_small = pos_leftpaper_top + bordersize;
var pos_leftpaper_left_small = pos_leftpaper_left + bordersize;


var pos_rightpaper_top = 0 ; // fix, dont change
var pos_rightpaper_left = - paper_width * 0.5 - imagebetweengap; // fix, dont change

var masright = pos_rightpaper_left + 1 * bordersize; // fix, dont change
var mastop = pos_rightpaper_top +  1 * bordersize; 

var maskwidth = paper_width - 2 * bordersize;
var maskheight = paper_size - 2 * bordersize;

var masgrayleft = pos_rightpaper_left + bordersize;
var masgraytop = pos_rightpaper_top + bordersize;

var graywidth = paper_width + bordersize ;
var grayheight = paper_size + bordersize ; 
}


///////////////////////////////////////////////////////////////////////////////
/////////////////////////////BUBBLE PART START/////////////////////////////////
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
/////////////// ------------ POSSIBLE BUBBLES ----------- /////////////////////

//Math.random() * (max - min) + min;

///////////////////////////////////////////////////////////////////////////////
/////////////// ------------ BUBBLE LOCATION ------------ /////////////////////

//----------------------//
//var bubccc = 5;

//-------------------



/*
var bubcase1 = [];
bubcase1.push(45);bubcase1.push(30);bubcase1.push(45);bubcase1.push(30);bubcase1.push(30);bubcase1.push(45);bubcase1.push(30);bubcase1.push(45);bubcase1.push(45);bubcase1.push(30);bubcase1.push(45);bubcase1.push(30);
var bubcase2 = [];
bubcase2.push(30);bubcase2.push(45);bubcase2.push(30);bubcase2.push(45);bubcase2.push(45);bubcase2.push(30);bubcase2.push(45);bubcase2.push(30);bubcase2.push(30);bubcase2.push(45);bubcase2.push(30);bubcase2.push(45);
var bubcase3 =[]; // 6,4,4,6 // 4,6,6,4 // 
bubcase3.push(45);bubcase3.push(30);bubcase3.push(30);bubcase3.push(45);bubcase3.push(30);bubcase3.push(45);bubcase3.push(45);bubcase3.push(30);bubcase3.push(45);bubcase3.push(30);bubcase3.push(30);bubcase3.push(45);
var bubcase4 =[]; // 4,6,6,4 // 6,4,4,6 // 
bubcase4.push(30);bubcase4.push(45);bubcase4.push(45);bubcase4.push(30);bubcase4.push(45);bubcase4.push(30);bubcase4.push(30);bubcase4.push(45);bubcase4.push(30);bubcase4.push(45);bubcase4.push(45);bubcase4.push(30);
*/

var bubcase1 = [];
bubcase1.push(60);bubcase1.push(40);bubcase1.push(60);bubcase1.push(40);bubcase1.push(40);bubcase1.push(60);bubcase1.push(40);bubcase1.push(60);bubcase1.push(60);bubcase1.push(40);bubcase1.push(60);bubcase1.push(40);

var bubcase2 = [];
bubcase2.push(40);bubcase2.push(60);bubcase2.push(40);bubcase2.push(60);bubcase2.push(60);bubcase2.push(40);bubcase2.push(60);bubcase2.push(40);bubcase2.push(40);bubcase2.push(60);bubcase2.push(40);bubcase2.push(60);

var bubcase3 =[]; // 6,4,4,6 // 4,6,6,4 // 
bubcase3.push(60);bubcase3.push(40);bubcase3.push(40);bubcase3.push(60);bubcase3.push(40);bubcase3.push(60);bubcase3.push(60);bubcase3.push(40);bubcase3.push(60);bubcase3.push(40);bubcase3.push(40);bubcase3.push(60);

var bubcase4 =[]; // 4,6,6,4 // 6,4,4,6 // 
bubcase4.push(40);bubcase4.push(60);bubcase4.push(60);bubcase4.push(40);bubcase4.push(60);bubcase4.push(40);bubcase4.push(40);bubcase4.push(60);bubcase4.push(40);bubcase4.push(60);bubcase4.push(60);bubcase4.push(40);




//var bubcase5 =[]; // 4,6,6,4 // 6,4,4,6 // 
//bubcase5.push(40);bubcase5.push(40);bubcase5.push(40);bubcase5.push(40);bubcase5.push(40);bubcase5.push(60);bubcase5.push(60);bubcase5.push(60);bubcase5.push(40);bubcase5.push(40);bubcase5.push(40);bubcase5.push(40);

/*
var smgap_x = 25;
var smgap_y = 20;
if (bubccc == 1){
  var bubsize = bubcase1 ; 
  // --- row 1
  var posr_11 = bubsize[0]; posx_11 = 1.2 * posr_11 ; posy_11 = 1.1* posr_11 ;
  var posr_12 = bubsize[1]; posx_12 = posx_11 + posr_11 + posr_12 + smgap_x ; posy_12 = posy_11 ; 
  var posr_13 = bubsize[2]; posx_13 = posx_12 + posr_12 + posr_13 + smgap_x ; posy_13 = posy_11 ; 
  var posr_14 = bubsize[3]; posx_14 = posx_13 + posr_13 + posr_14 + smgap_x ; posy_14 = posy_11 ; 
  // --- row 2
  var posr_21 = bubsize[4]; posx_21 = posx_11 ; posy_21 = posy_11 + posr_11 + posr_21 + smgap_y ; 
  var posr_22 = bubsize[5]; posx_22 = posx_21 + posr_21 + posr_22 + smgap_x ; posy_22 = posy_12 + posr_12 + posr_22 + smgap_y ; 
  var posr_23 = bubsize[6]; posx_23 = posx_22 + posr_22 + posr_23 + smgap_x ; posy_23 = posy_13 + posr_13 + posr_23 + smgap_y ; 
  var posr_24 = bubsize[7]; posx_24 = posx_23 + posr_23 + posr_24 + smgap_x ; posy_24 = posy_14 + posr_14 + posr_24 + smgap_y ;
  // --- row 3
  var posr_31 = bubsize[8]; posx_31 = posx_11 ; posy_31 = posy_21 + posr_21 + posr_31 + smgap_y ; 
  var posr_32 = bubsize[9]; posx_32 = posx_31 + posr_31 + posr_32 + smgap_x ; posy_32 = posy_22 + posr_22 + posr_32 + smgap_y ; 
  var posr_33 = bubsize[10]; posx_33 = posx_32 + posr_32 + posr_33 + smgap_x ; posy_33 = posy_23 + posr_23 + posr_33 + smgap_y ; 
  var posr_34 = bubsize[11]; posx_34 = posx_33 + posr_33 + posr_34 + smgap_x ; posy_34 = posy_24 + posr_24 + posr_34 + smgap_y ;

}else if(bubccc == 2){
  var bubsize = bubcase2 ; 
  // --- row 1
  var posr_11 = bubsize[0]; posx_11 = 1.65* posr_11 ; posy_11 = 1.65* posr_11 ;
  var posr_12 = bubsize[1]; posx_12 = posx_11 + posr_11 + posr_12 + smgap_x ; posy_12 = posy_11 ; // r = 60
  var posr_13 = bubsize[2]; posx_13 = posx_12 + posr_12 + posr_13 + smgap_x ; posy_13 = posy_11 ; 
  var posr_14 = bubsize[3]; posx_14 = posx_13 + posr_13 + posr_14 + smgap_x ; posy_14 = posy_11 ; 
  // --- row 2
  var posr_21 = bubsize[4]; posx_21 = posx_11 + smgap_x * 0.4 ; posy_21 = posy_11 + posr_11 + posr_21 + smgap_y ; //r= 60
  var posr_22 = bubsize[5]; posx_22 = posx_21 + posr_21 + posr_22 + smgap_x ; posy_22 = posy_12 + posr_12 + posr_22 + smgap_y ; 
  var posr_23 = bubsize[6]; posx_23 = posx_22 + posr_22 + posr_23 + smgap_x ; posy_23 = posy_13 + posr_13 + posr_23 + smgap_y ; 
  var posr_24 = bubsize[7]; posx_24 = posx_23 + posr_23 + posr_24 + smgap_x ; posy_24 = posy_14 + posr_14 + posr_24 + smgap_y ;
  // --- row 3
  var posr_31 = bubsize[8]; posx_31 = posx_11 ; posy_31 = posy_21 + posr_21 + posr_31 + smgap_y ; 
  var posr_32 = bubsize[9]; posx_32 = posx_31 + posr_31 + posr_32 + smgap_x ; posy_32 = posy_22 + posr_22 + posr_32 + smgap_y ; 
  var posr_33 = bubsize[10]; posx_33 = posx_32 + posr_32 + posr_33 + smgap_x ; posy_33 = posy_23 + posr_23 + posr_33 + smgap_y ; 
  var posr_34 = bubsize[11]; posx_34 = posx_33 + posr_33 + posr_34 + smgap_x ; posy_34 = posy_24 + posr_24 + posr_34 + smgap_y ;
}else if(bubccc == 3){
  var bubsize = bubcase3 ; 
  // --- row 1
  var posr_11 = bubsize[0]; posx_11 = 1.35 * posr_11 ; posy_11 = 1.1* posr_11 ;
  var posr_12 = bubsize[1]; posx_12 = posx_11 + posr_11 + posr_12 + smgap_x ; posy_12 = posy_11 ; // r = 60
  var posr_13 = bubsize[2]; posx_13 = posx_12 + posr_12 + posr_13 + smgap_x ; posy_13 = posy_11 ; 
  var posr_14 = bubsize[3]; posx_14 = posx_13 + posr_13 + posr_14 + smgap_x ; posy_14 = posy_11 ; 
  // --- row 2
  var posr_21 = bubsize[4]; posx_21 = posx_11 - smgap_x * 0.6; posy_21 = posy_11 + posr_11 + posr_21 + smgap_y ; //r= 60
  var posr_22 = bubsize[5]; posx_22 = posx_21 + posr_21 + posr_22 + smgap_x ; posy_22 = posy_12 + posr_12 + posr_22 + smgap_y ; 
  var posr_23 = bubsize[6]; posx_23 = posx_22 + posr_22 + posr_23 + smgap_x ; posy_23 = posy_13 + posr_13 + posr_23 + smgap_y ; 
  var posr_24 = bubsize[7]; posx_24 = posx_23 + posr_23 + posr_24 + smgap_x ; posy_24 = posy_14 + posr_14 + posr_24 + smgap_y ;
  // --- row 3
  var posr_31 = bubsize[8]; posx_31 = posx_11 ; posy_31 = posy_21 + posr_21 + posr_31 + smgap_y ; 
  var posr_32 = bubsize[9]; posx_32 = posx_31 + posr_31 + posr_32 + smgap_x ; posy_32 = posy_22 + posr_22 + posr_32 + smgap_y ; 
  var posr_33 = bubsize[10]; posx_33 = posx_32 + posr_32 + posr_33 + smgap_x ; posy_33 = posy_23 + posr_23 + posr_33 + smgap_y ; 
  var posr_34 = bubsize[11]; posx_34 = posx_33 + posr_33 + posr_34 + smgap_x ; posy_34 = posy_24 + posr_24 + posr_34 + smgap_y ;
}else if(bubccc == 4){
  var bubsize = bubcase4; 
  // --- row 1
  //var posr_11 = bubsize[0]; posx_11 = 0.15 * posr_11 ; posy_11 = 0.5* posr_11 ;
  var posr_11 = bubsize[0]; posx_11 = 1.5 * posr_11 ; posy_11 =1.65* posr_11 ;
  var posr_12 = bubsize[1]; posx_12 = posx_11 + posr_11 + posr_12 + smgap_x ; posy_12 = posy_11 ; // r = 60
  var posr_13 = bubsize[2]; posx_13 = posx_12 + posr_12 + posr_13 + smgap_x ; posy_13 = posy_11 ; 
  var posr_14 = bubsize[3]; posx_14 = posx_13 + posr_13 + posr_14 + smgap_x ; posy_14 = posy_11 ; 
  // --- row 2
  var posr_21 = bubsize[4]; posx_21 = posx_11 + smgap_x * 0.65; posy_21 = posy_11 + posr_11 + posr_21 + smgap_y ; //r= 60
  var posr_22 = bubsize[5]; posx_22 = posx_21 + posr_21 + posr_22 + smgap_x ; posy_22 = posy_12 + posr_12 + posr_22 + smgap_y ; 
  var posr_23 = bubsize[6]; posx_23 = posx_22 + posr_22 + posr_23 + smgap_x ; posy_23 = posy_13 + posr_13 + posr_23 + smgap_y ; 
  var posr_24 = bubsize[7]; posx_24 = posx_23 + posr_23 + posr_24 + smgap_x ; posy_24 = posy_14 + posr_14 + posr_24 + smgap_y ;
  // --- row 3
  var posr_31 = bubsize[8]; posx_31 = posx_11 ; posy_31 = posy_21 + posr_21 + posr_31 + smgap_y ; 
  var posr_32 = bubsize[9]; posx_32 = posx_31 + posr_31 + posr_32 + smgap_x ; posy_32 = posy_22 + posr_22 + posr_32 + smgap_y ; 
  var posr_33 = bubsize[10]; posx_33 = posx_32 + posr_32 + posr_33 + smgap_x ; posy_33 = posy_23 + posr_23 + posr_33 + smgap_y ; 
  var posr_34 = bubsize[11]; posx_34 = posx_33 + posr_33 + posr_34 + smgap_x ; posy_34 = posy_24 + posr_24 + posr_34 + smgap_y ;
}
*/

var smgap_x = 25;
var smgap_y = 25;

if (bubccc == 1){
  var bubsize = bubcase1 ; 
  // --- row 1
  var posr_11 = bubsize[0]; posx_11 = 0.3 * posr_11 ; posy_11 = 0.3* posr_11 ;
  var posr_12 = bubsize[1]; posx_12 = posx_11 + posr_11 + posr_12 + smgap_x ; posy_12 = posy_11 ; 
  var posr_13 = bubsize[2]; posx_13 = posx_12 + posr_12 + posr_13 + smgap_x ; posy_13 = posy_11 ; 
  var posr_14 = bubsize[3]; posx_14 = posx_13 + posr_13 + posr_14 + smgap_x ; posy_14 = posy_11 ; 
  // --- row 2
  var posr_21 = bubsize[4]; posx_21 = posx_11 ; posy_21 = posy_11 + posr_11 + posr_21 + smgap_y ; 
  var posr_22 = bubsize[5]; posx_22 = posx_21 + posr_21 + posr_22 + smgap_x ; posy_22 = posy_12 + posr_12 + posr_22 + smgap_y ; 
  var posr_23 = bubsize[6]; posx_23 = posx_22 + posr_22 + posr_23 + smgap_x ; posy_23 = posy_13 + posr_13 + posr_23 + smgap_y ; 
  var posr_24 = bubsize[7]; posx_24 = posx_23 + posr_23 + posr_24 + smgap_x ; posy_24 = posy_14 + posr_14 + posr_24 + smgap_y ;
  // --- row 3
  var posr_31 = bubsize[8]; posx_31 = posx_11 ; posy_31 = posy_21 + posr_21 + posr_31 + smgap_y ; 
  var posr_32 = bubsize[9]; posx_32 = posx_31 + posr_31 + posr_32 + smgap_x ; posy_32 = posy_22 + posr_22 + posr_32 + smgap_y ; 
  var posr_33 = bubsize[10]; posx_33 = posx_32 + posr_32 + posr_33 + smgap_x ; posy_33 = posy_23 + posr_23 + posr_33 + smgap_y ; 
  var posr_34 = bubsize[11]; posx_34 = posx_33 + posr_33 + posr_34 + smgap_x ; posy_34 = posy_24 + posr_24 + posr_34 + smgap_y ;

}else if(bubccc == 2){
  var bubsize = bubcase2 ; 
  // --- row 1
  var posr_11 = bubsize[0]; posx_11 = 0.3 * posr_11 ; posy_11 = 0.45* posr_11 ;
  var posr_12 = bubsize[1]; posx_12 = posx_11 + posr_11 + posr_12 + smgap_x ; posy_12 = posy_11 ; // r = 60
  var posr_13 = bubsize[2]; posx_13 = posx_12 + posr_12 + posr_13 + smgap_x ; posy_13 = posy_11 ; 
  var posr_14 = bubsize[3]; posx_14 = posx_13 + posr_13 + posr_14 + smgap_x ; posy_14 = posy_11 ; 
  // --- row 2
  var posr_21 = bubsize[4]; posx_21 = posx_11 + smgap_x * 0.4 ; posy_21 = posy_11 + posr_11 + posr_21 + smgap_y ; //r= 60
  var posr_22 = bubsize[5]; posx_22 = posx_21 + posr_21 + posr_22 + smgap_x ; posy_22 = posy_12 + posr_12 + posr_22 + smgap_y ; 
  var posr_23 = bubsize[6]; posx_23 = posx_22 + posr_22 + posr_23 + smgap_x ; posy_23 = posy_13 + posr_13 + posr_23 + smgap_y ; 
  var posr_24 = bubsize[7]; posx_24 = posx_23 + posr_23 + posr_24 + smgap_x ; posy_24 = posy_14 + posr_14 + posr_24 + smgap_y ;
  // --- row 3
  var posr_31 = bubsize[8]; posx_31 = posx_11 ; posy_31 = posy_21 + posr_21 + posr_31 + smgap_y ; 
  var posr_32 = bubsize[9]; posx_32 = posx_31 + posr_31 + posr_32 + smgap_x ; posy_32 = posy_22 + posr_22 + posr_32 + smgap_y ; 
  var posr_33 = bubsize[10]; posx_33 = posx_32 + posr_32 + posr_33 + smgap_x ; posy_33 = posy_23 + posr_23 + posr_33 + smgap_y ; 
  var posr_34 = bubsize[11]; posx_34 = posx_33 + posr_33 + posr_34 + smgap_x ; posy_34 = posy_24 + posr_24 + posr_34 + smgap_y ;
}else if(bubccc == 3){
  var bubsize = bubcase3 ; 
  // --- row 1
  var posr_11 = bubsize[0]; posx_11 = 0.4 * posr_11 ; posy_11 = 0.3* posr_11 ;
  var posr_12 = bubsize[1]; posx_12 = posx_11 + posr_11 + posr_12 + smgap_x ; posy_12 = posy_11 ; // r = 60
  var posr_13 = bubsize[2]; posx_13 = posx_12 + posr_12 + posr_13 + smgap_x ; posy_13 = posy_11 ; 
  var posr_14 = bubsize[3]; posx_14 = posx_13 + posr_13 + posr_14 + smgap_x ; posy_14 = posy_11 ; 
  // --- row 2
  var posr_21 = bubsize[4]; posx_21 = posx_11 - smgap_x * 0.7; posy_21 = posy_11 + posr_11 + posr_21 + smgap_y ; //r= 60
  var posr_22 = bubsize[5]; posx_22 = posx_21 + posr_21 + posr_22 + smgap_x ; posy_22 = posy_12 + posr_12 + posr_22 + smgap_y ; 
  var posr_23 = bubsize[6]; posx_23 = posx_22 + posr_22 + posr_23 + smgap_x ; posy_23 = posy_13 + posr_13 + posr_23 + smgap_y ; 
  var posr_24 = bubsize[7]; posx_24 = posx_23 + posr_23 + posr_24 + smgap_x ; posy_24 = posy_14 + posr_14 + posr_24 + smgap_y ;
  // --- row 3
  var posr_31 = bubsize[8]; posx_31 = posx_11 ; posy_31 = posy_21 + posr_21 + posr_31 + smgap_y ; 
  var posr_32 = bubsize[9]; posx_32 = posx_31 + posr_31 + posr_32 + smgap_x ; posy_32 = posy_22 + posr_22 + posr_32 + smgap_y ; 
  var posr_33 = bubsize[10]; posx_33 = posx_32 + posr_32 + posr_33 + smgap_x ; posy_33 = posy_23 + posr_23 + posr_33 + smgap_y ; 
  var posr_34 = bubsize[11]; posx_34 = posx_33 + posr_33 + posr_34 + smgap_x ; posy_34 = posy_24 + posr_24 + posr_34 + smgap_y ;
}else if(bubccc == 4){
  var bubsize = bubcase4; 
  // --- row 1
  var posr_11 = bubsize[0]; posx_11 = 0.15 * posr_11 ; posy_11 = 0.5* posr_11 ;
  var posr_12 = bubsize[1]; posx_12 = posx_11 + posr_11 + posr_12 + smgap_x ; posy_12 = posy_11 ; // r = 60
  var posr_13 = bubsize[2]; posx_13 = posx_12 + posr_12 + posr_13 + smgap_x ; posy_13 = posy_11 ; 
  var posr_14 = bubsize[3]; posx_14 = posx_13 + posr_13 + posr_14 + smgap_x ; posy_14 = posy_11 ; 
  // --- row 2
  var posr_21 = bubsize[4]; posx_21 = posx_11 + smgap_x * 0.8 ; posy_21 = posy_11 + posr_11 + posr_21 + smgap_y ; //r= 60
  var posr_22 = bubsize[5]; posx_22 = posx_21 + posr_21 + posr_22 + smgap_x ; posy_22 = posy_12 + posr_12 + posr_22 + smgap_y ; 
  var posr_23 = bubsize[6]; posx_23 = posx_22 + posr_22 + posr_23 + smgap_x ; posy_23 = posy_13 + posr_13 + posr_23 + smgap_y ; 
  var posr_24 = bubsize[7]; posx_24 = posx_23 + posr_23 + posr_24 + smgap_x ; posy_24 = posy_14 + posr_14 + posr_24 + smgap_y ;
  // --- row 3
  var posr_31 = bubsize[8]; posx_31 = posx_11 ; posy_31 = posy_21 + posr_21 + posr_31 + smgap_y ; 
  var posr_32 = bubsize[9]; posx_32 = posx_31 + posr_31 + posr_32 + smgap_x ; posy_32 = posy_22 + posr_22 + posr_32 + smgap_y ; 
  var posr_33 = bubsize[10]; posx_33 = posx_32 + posr_32 + posr_33 + smgap_x ; posy_33 = posy_23 + posr_23 + posr_33 + smgap_y ; 
  var posr_34 = bubsize[11]; posx_34 = posx_33 + posr_33 + posr_34 + smgap_x ; posy_34 = posy_24 + posr_24 + posr_34 + smgap_y ;
}

var clippos = '\
<circle cx="' + posx_11 +'" cy="'+posy_11+'" r="'+posr_11+'" />\
<circle cx="' + posx_12 +'" cy="'+posy_12+'" r="'+posr_12+'" />\
<circle cx="' + posx_13 +'" cy="'+posy_13+'" r="'+posr_13+'" />\
<circle cx="' + posx_14 +'" cy="'+posy_14+'" r="'+posr_14+'" />\
<circle cx="' + posx_21 +'" cy="'+posy_21+'" r="'+posr_21+'" />\
<circle cx="' + posx_22 +'" cy="'+posy_22+'" r="'+posr_22+'" />\
<circle cx="' + posx_23 +'" cy="'+posy_23+'" r="'+posr_23+'" />\
<circle cx="' + posx_24 +'" cy="'+posy_24+'" r="'+posr_24+'" />\
<circle cx="' + posx_31 +'" cy="'+posy_31+'" r="'+posr_31+'" />\
<circle cx="' + posx_32 +'" cy="'+posy_32+'" r="'+posr_32+'" />\
<circle cx="' + posx_33 +'" cy="'+posy_33+'" r="'+posr_33+'" />\
<circle cx="' + posx_34 +'" cy="'+posy_34+'" r="'+posr_34+'" />\
'

/////////////////////////////////gray area///////////////////////////////////////////////

var distgrybac_x = bordersize ;//+ 0.5* (paper_width - maskwidth); 
var distgrybac_y = bordersize ;//+ 0.5*(paper_size - maskheight); 

var gposr_11 = bubsize[0]; gposx_11 = posx_11 + distgrybac_x; gposy_11 = posy_11 + distgrybac_y;
var gposr_12 = bubsize[1]; gposx_12 = posx_12 + distgrybac_x; gposy_12 = posy_12 + distgrybac_y; 
var gposr_13 = bubsize[2]; gposx_13 = posx_13 + distgrybac_x; gposy_13 = posy_13 + distgrybac_y; 
var gposr_14 = bubsize[3]; gposx_14 = posx_14 + distgrybac_x; gposy_14 = posy_14 + distgrybac_y; 
// --- row 2
var gposr_21 = bubsize[4]; gposx_21 = posx_21 + distgrybac_x; gposy_21 = posy_21 + distgrybac_y; 
var gposr_22 = bubsize[5]; gposx_22 = posx_22 + distgrybac_x; gposy_22 = posy_22 + distgrybac_y; 
var gposr_23 = bubsize[6]; gposx_23 = posx_23 + distgrybac_x; gposy_23 = posy_23 + distgrybac_y; 
var gposr_24 = bubsize[7]; gposx_24 = posx_24 + distgrybac_x; gposy_24 = posy_24 + distgrybac_y;
// --- row 3
var gposr_31 = bubsize[8]; gposx_31 = posx_31 + distgrybac_x; gposy_31 = posy_31 + distgrybac_y; 
var gposr_32 = bubsize[9]; gposx_32 = posx_32 + distgrybac_x; gposy_32 = posy_32 + distgrybac_y; 
var gposr_33 = bubsize[10]; gposx_33 = posx_33 + distgrybac_x; gposy_33 = posy_33 + distgrybac_y; 
var gposr_34 = bubsize[11]; gposx_34 = posx_34 + distgrybac_x; gposy_34 = posy_34 + distgrybac_y;


var gclippos = '\
<circle cx="' + gposx_11 +'" cy="'+gposy_11+'" r="'+gposr_11+'" />\
<circle cx="' + gposx_12 +'" cy="'+gposy_12+'" r="'+gposr_12+'" />\
<circle cx="' + gposx_13 +'" cy="'+gposy_13+'" r="'+gposr_13+'" />\
<circle cx="' + gposx_14 +'" cy="'+gposy_14+'" r="'+gposr_14+'" />\
<circle cx="' + gposx_21 +'" cy="'+gposy_21+'" r="'+gposr_21+'" />\
<circle cx="' + gposx_22 +'" cy="'+gposy_22+'" r="'+gposr_22+'" />\
<circle cx="' + gposx_23 +'" cy="'+gposy_23+'" r="'+gposr_23+'" />\
<circle cx="' + gposx_24 +'" cy="'+gposy_24+'" r="'+gposr_24+'" />\
<circle cx="' + gposx_31 +'" cy="'+gposy_31+'" r="'+gposr_31+'" />\
<circle cx="' + gposx_32 +'" cy="'+gposy_32+'" r="'+gposr_32+'" />\
<circle cx="' + gposx_33 +'" cy="'+gposy_33+'" r="'+gposr_33+'" />\
<circle cx="' + gposx_34 +'" cy="'+gposy_34+'" r="'+gposr_34+'" />\
'


////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////
/// ------------ PICK THE BUBBLE TO DISPLAY ELEMENTS ---------------- ///

//var allposrand = jsPsych.randomization.sampleWithoutReplacement(allpos, allpos.length);

////////////////////////////////////////////////////////////////////////////////////
/////////////////-------------------------------------------- //////////////////////
/////////// ALL POSSIBLE LOCATIONS TO DISPLAY ELEMENT IN THE BUBBLES /////////////// 
/*
var display_x = [];
var display_y = [];
var display_locs_x = [];
var display_locs_y = [];
var display_locs = [];


for (var t=0; t < allpos.length; t++){
    var dimet1 = Math.floor( 0.5 * Math.sqrt(2) * allposrand[t][0] ); 
    var num1 = Math.floor(dimet1 / 21);
    var locx = allposrand[t][1] - dimet1 - 1 * trial.target_size[0] + pos_rightpaper_left + imagebetweengap ;
    var locy = allposrand[t][2] - dimet1 ;
    for (var i = 0; i < num1; i++) {
       locx += i* 30 + 7 * (Math.random() * (2) -1) ;
      for (var j = 0; j < num1 ; j++) {
         locy += j *30 + 5 * ( Math.random() * (2) -1 );
            display_x.push(locx);
            display_y.push(locy);
      }  
    }
}

var aa = [];
for (var i = 0; i < number_stim; i++) {
   aa.push(i);
}
var randaa = jsPsych.randomization.sampleWithoutReplacement(aa,aa.length) ; 
for(var i = 0; i<number_stim; i++){
  var b = randaa[i]; 
  display_locs_x.push(display_x[b]);
  display_locs_y.push(display_y[b]);
   }
*/
///////////////////////////////new bubble grid/////////////////////////////////

//------------ bubcase1 -- maskmat1 (60,40,60,40
//-----------------------------------40,60,40,60,
//-----------------------------------60,40,60,40)

var maskmat1 = [1,1,0,0,1,0,0,1,1,
               1,0,0,0,0,0,0,0,1,
               0,0,0,0,0,0,0,0,0,
               1,0,0,1,1,1,0,0,1,
               1,0,0,1,1,1,0,0,1,
               0,0,0,0,1,0,0,0,0,
               0,0,0,0,0,0,0,0,0,
               1,1,0,0,1,0,0,1,1,
               1,1,0,0,1,0,0,1,1,
               0,0,0,0,0,0,0,0,1,
               0,0,0,0,0,0,0,0,0,
               1,0,0,1,1,1,0,0,1];


var maskmat3 = [1,1,0,0,1,0,0,1,1,
               1,0,0,0,0,0,0,0,1,
               0,0,0,0,1,0,0,0,0,
               1,0,0,1,1,1,0,0,1,
               1,0,0,1,1,1,0,0,1,
               0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,
               1,0,0,1,1,1,0,1,1,
               0,0,0,1,1,1,0,0,1,
               0,0,0,1,1,0,0,0,0,
               1,0,0,0,0,0,0,1,1,
               1,1,0,0,1,0,0,1,1];



var maskmat2 = [1,0,0,1,1,1,0,0,1,
               0,0,0,0,1,0,0,0,0,
               1,0,0,0,0,0,0,0,1,
               1,1,0,0,1,0,0,1,1,
               1,1,0,0,1,0,0,1,1,
               0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,
               1,0,0,1,1,1,0,1,1,
               1,0,0,1,1,1,0,0,1,
               0,0,0,0,1,0,0,0,0,
               1,0,0,0,0,0,0,0,1,
               1,1,0,0,1,0,0,1,1];

var maskmat4 = [1,0,0,1,1,1,0,0,1,
                0,0,0,0,1,0,0,0,0,
                1,0,0,0,0,0,0,0,0,
                1,1,0,0,0,0,0,1,1,
                1,1,0,0,1,0,0,1,1,
                0,0,0,0,0,0,0,0,0,
                0,0,0,0,0,0,0,0,0,
                1,1,0,0,1,0,0,1,1,
                1,1,0,0,1,0,0,1,1,
                1,0,0,0,0,0,0,0,1,
                0,0,0,1,1,0,0,0,0,
                1,0,0,1,1,1,0,0,1];

               var maskmat5 = [1,1,0,0,1,0,0,1,1,
               1,0,0,0,0,0,0,0,1,
               0,0,0,0,1,0,0,0,0,
               1,0,0,1,1,1,0,0,1,
               1,0,0,1,1,1,0,0,1,
               0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,
               1,0,0,1,1,1,0,1,1,
               0,0,0,1,1,1,0,0,1,
               0,0,0,1,1,0,0,0,0,
               1,0,0,0,0,0,0,1,1,
               1,1,0,0,1,0,0,1,1];

               var maskmat6 = [1,1,0,0,1,0,0,1,1,
               1,0,0,0,0,0,0,0,1,
               0,0,0,0,1,0,0,0,0,
               1,0,0,1,1,1,0,0,1,
               1,0,0,1,1,1,0,0,1,
               0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,
               1,0,0,1,1,1,0,1,1,
               0,0,0,1,1,1,0,0,1,
               0,0,0,1,1,0,0,0,0,
               1,0,0,0,0,0,0,1,1,
               1,1,0,0,1,0,0,1,1];
////////////////

if (bubccc == 1){
  var maskmat = maskmat1;
}else if(bubccc ==2){
  var maskmat = maskmat2;
}
else if(bubccc ==3){
  var maskmat = maskmat3;
}else if(bubccc ==4){
  var maskmat = maskmat4;
}
else if(bubccc ==5){
  var maskmat = maskmat5;
}else if(bubccc ==6){
  var maskmat = maskmat6;
}



var targetgrid = trial.target_size[0] * 1.5 ;
var col = Math.floor(maskwidth / targetgrid );
var row = Math.floor(maskheight / targetgrid );
var totalnum = col * row;
var possible_grids = [];
for (var i = 0; i < col ; i++){
  for (var j = 0; j < row ; j++){
      possible_grids.push([i * targetgrid + pos_rightpaper_left + imagebetweengap + bordersize, j * targetgrid + pos_rightpaper_top + bordersize + 0.5*trial.target_size[0]])
    }
}

var display_x = [];
var display_y = [];
var display_locs_x =[];
var display_locs_y =[];
var display_locs_r_x =[];
var display_locs_r_y =[];
var display_or_not = [];

for (var m = 0; m < totalnum; m++){
  display_x.push(possible_grids[m][0]);
  display_y.push(possible_grids[m][1]);
  display_or_not.push(maskmat[m]);
}

///// ------- randomly pick display locations --- judge whether it is occluded
var aa = [];
for (var i = 0; i < totalnum; i++) {
   aa.push(i);
}
if (disord == "hybrid-occludleft" || disord =="hybrid-occludright"){
      var randaa = jsPsych.randomization.sampleWithoutReplacement(aa,aa.length) ;

      var visistim = 0;
      var displaynum = 0;
      while (visistim < number_stim){
        var b = randaa[displaynum]; 
        if (display_or_not[b]==1){
          display_locs_x.push(display_x[b]);
          display_locs_y.push(display_y[b]);
          visistim += 1;
        }
        displaynum += 1;
      }

      ////////////////////////////BUBBLE PART END////////////////////////////////////
      ///***********************NO OCCLUSION PART START***************************///

      if (disord == "hybrid-occludright"){
      /// ------- OCCLUSION RIGHT - NO OCCLUSION LEFT -------
      var lrx = 0  + paper_width * 1 + bordersize; //+ trial.target_size[0] * 0.5 ;
     // var lry = 0 + trial.target_size[0] ;
      }else{
      /// ------- OCCLUSION LEFT - NO OCCLUSION RIGHT -------
      var lrx = - paper_width  - bordersize ; //imagebetweengap + paper_width * 0.5 + trial.target_size[0] ;
     // var lry = 0 + trial.target_size[0] + 0.5 ;
      }
        var randaa_r = jsPsych.randomization.sampleWithoutReplacement(aa,aa.length) ;
      var visistim_r = 0;
      var displaynum_r = 0;
      while (visistim_r < number_stim_r){
        var br = randaa_r[displaynum_r]; 
        if (display_or_not[b]==1){
          display_locs_r_x.push(display_x[br] + lrx);
          display_locs_r_y.push(display_y[br]);
          visistim_r += 1;
        }
        displaynum_r += 1;
      }
    }else if (disord == "both-occlude"){
                  //-----DISPLAY ON THE LEFT ----
      var randaa = jsPsych.randomization.sampleWithoutReplacement(aa,aa.length) ;
      var visistim = 0;
      var displaynum = 0;
      while (visistim < number_stim){
          var b = randaa[displaynum]; 
        if (display_or_not[b]==1){
          display_locs_x.push(display_x[b] )//;+ paper_width + bordersize + 0.5 * trial.target_size[0]); // don't change
          display_locs_y.push(display_y[b]);
          visistim += 1;
        }
         displaynum += 1;
      }
                  //-----DISPLAY ON THE RIGHT ------ 
      var randaa_r = jsPsych.randomization.sampleWithoutReplacement(aa,aa.length) ;
      var visistim_r = 0;
      var displaynum_r = 0;
      while (visistim_r < number_stim_r){
        var br = randaa_r[displaynum_r]; 
        if (display_or_not[br]==1){
          display_locs_r_x.push(display_x[br] + paper_width + bordersize * 1 - 0.5 * trial.target_size[0]);
          display_locs_r_y.push(display_y[br]);
          visistim_r += 1;
        }
        displaynum_r += 1;
      }
    }else if (disord == "both-no"){
      ///// -------------DISPLAY ON THE LEFT ------ 
      var randaa = jsPsych.randomization.sampleWithoutReplacement(aa,aa.length) ;
      var visistim = 0;
            var displaynum = 0;
            while (visistim < number_stim){
                var b = randaa[displaynum]; 
                display_locs_x.push(display_x[b] );
                display_locs_y.push(display_y[b]);
                visistim += 1;
              displaynum += 1;
            }
            /////// ---------- DISPLAY ON THE RIGHT ------- 
      var randaa_r = jsPsych.randomization.sampleWithoutReplacement(aa,aa.length) ;
      var visistim_r = 0;
            var displaynum_r = 0;
            while (visistim_r < number_stim_r){
              var br = randaa_r[displaynum_r]; 
                display_locs_r_x.push(display_x[br] + paper_width + bordersize - 0.5 * trial.target_size[0]);
                display_locs_r_y.push(display_y[br]);
                visistim_r += 1;
              displaynum_r += 1;
      }


}

///*************************************************************************///
///*************************************************************************///
///*************************************************************************///
///*************************************************************************///
///***********************NO OCCLUSION PART END*****************************///
///*************************************************************************///
///*************************************************************************///
///*************************************************************************///
///*************************************************************************///
 
display_element.innerHTML += '<div id="jspsych-visual-search-circle-container" style= "position: relative; width:' + paper_width + 'px; height:' + paper_size + 'px; top:'+ pos_paper_top + 'px; left:' + pos_paper_left + 'px;"></div>';
 
var paper = display_element.querySelector("#jspsych-visual-search-circle-container");

//var paper = display_element.innerHTML += "<img src='img/testback1.png'></img>";


    // check distractors - array?
   /* if(!Array.isArray(trial.foil)){
      fa = [];
      for(var i=0; i<trial.set_size; i++){
        fa.push(trial.foil);
      }
      trial.foil = fa;
    }*/


var elments = [];
elments.push("shape1");elments.push("shape2");elments.push("shape3");elments.push("shape4");elments.push("shape5");elments.push("shape6");elments.push("shape7");elments.push("shape8");


var to_present = [];
for (var ss=0; ss < number_stim; ss++){
   var smpnu = Math.floor(Math.random() * (7 - 0) );
   to_present.push(elments[smpnu]);
 }
var to_present_r = [];
for (var ss=0; ss < number_stim_r; ss++){
   var smpnu = Math.floor(Math.random() * (7 - 0)) ;
   to_present_r.push(elments[smpnu]);
 }

//var to_present = jsPsych.randomization.sampleWithReplacement(["shape1", "shape2", "shape3", "shape4","shape5", "shape6", "shape7", "shape8"], number_stim);
//var to_present_r = jsPsych.randomization.sampleWithReplacement(["shape1", "shape2", "shape3", "shape4","shape5", "shape6", "shape7", "shape8"], number_stim_r);


var dff = display_locs_y.length - display_locs_r_y.length; 

if (dff > 0){
  for (var tt = 0; tt < dff; tt++){
    display_locs_r_x.push(0 + paper_width * 0.49); 
    display_locs_r_y.push(0);
    to_present_r.push("backgrd"); 
    } 
 } 
if (dff < 0){
   for (var tt = 0; tt < -dff ; tt++){
    display_locs_x.push(0 + paper_width * 0.49);
    display_locs_y.push(0);
    to_present.push("backgrd"); 
   //  to_present.push(elments[smpnu]);
    }
  }






///////**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**///////
///////**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**///////
///////**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**///////
///////**--**--**--**--**--**--**--**--**--DISPLAY-**--**--**--**--**--**--**--**--**--**--**///////
///////**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**///////
///////**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**///////
///////**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**///////

show_search_array();

function show_search_array() {


var disstr=" "
for (var i = 0; i < Math.max(display_locs_y.length, display_locs_r_y.length); i++ ){
  //for (var i = 0; i < 15; i++ ){
disstr +='<img class = "imagesub" src="img/'+ to_present[i]+'.png" style="--imsub_postop:'+ display_locs_y[i]+'px; --imsub_posleft:'+ display_locs_x[i]+'px; width:'+trial.target_size[0]+'px; height:'+trial.target_size[1]+'px;"><img class = "imagesub" src="img/'+ to_present_r[i]+'.png" style="--imsub_postop:'+ display_locs_r_y[i]+'px; --imsub_posleft:'+ display_locs_r_x[i]+'px; width:'+trial.target_size[0]+'px; height:'+trial.target_size[1]+'px;">';
} 

if (disord == "hybrid-occludleft" || disord =="hybrid-occludright"){
  paper.innerHTML = '<div class = "backleft">\
  <img class = "imageleft" src="img/greenbacknewer.png" style = "--imleft_posleft:'+pos_leftpaper_left+'px;  --imleft_postop:'+ pos_rightpaper_top +'px;  width:' + paper_width  + 'px; height:' + paper_size + 'px;">\
  <img class = "clip-svg" src="img/graydark.png" style = "--mask_posleft:'+ pos_leftpaper_left + 'px; --mask_postop: '+ pos_rightpaper_top +'px; width:'+ paper_width +'px; height:' + paper_size + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip">'+ gclippos +'</clipPath></defs></svg>\
      <img class = "imageleft" src="img/Holz1.jpg" style= "--imleft_posleft:'+ pos_leftpaper_left_small +'px; --imleft_postop:'+ pos_leftpaper_top_small+'px; width:' + maskwidth + 'px; height:' + maskheight + 'px;">\
            <img class = "imageleft" src="img/greenbacknewer.png" style = "--imleft_posleft:'+ pos_rightpaper_left+'px;  --imleft_postop:'+ pos_leftpaper_top +'px;  width:' + paper_width  + 'px; height:' + paper_size + 'px;">\
        <img class = "clip-svg3" src="img/graydark.png" style = "--mask_posleft:'+ pos_rightpaper_left + 'px; --mask_postop: '+ pos_leftpaper_top +'px; width:'+ paper_width +'px; height:' + paper_size + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip3">'+ gclippos +'</clipPath></defs></svg>\
         <img class = "clip-svg2" src="img/Holz1.jpg" style = "--mask_posleft:'+ masright + 'px; --mask_postop: '+ mastop +'px; width:'+ maskwidth +'px; height:' + maskheight + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip2">'+ clippos +'</clipPath></defs></svg>\
          </div>';


//// 



      //<img class = "imageleft" src="img/Holz1.jpg" style= "--imleft_posleft:'+ pos_leftpaper_left_small +'px; --imleft_postop:'+ pos_leftpaper_top_small+'px; width:' + maskwidth + 'px; height:' + maskheight + 'px;">\
//<img class = "clip-svg2" src="img/Holz1.jpg" style = "--mask_posleft:'+ masright + 'px; --mask_postop: '+ mastop +'px; width:'+ maskwidth +'px; height:' + maskheight + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip2">'+ clippos +'</clipPath></defs></svg>\

 // <img class = "imageleft" src="img/Holz1.jpg" style= "--imleft_posleft:'+ pos_leftpaper_left_small +'px; --imleft_postop:'+ pos_leftpaper_top_small+'px; width:' + maskwidth + 'px; height:' + maskheight + 'px;">\
//<img class = "clip-svg2" src="img/Holz1.jpg" style = "--mask_posleft:'+ masright + 'px; --mask_postop: '+ mastop +'px; width:'+ maskwidth +'px; height:' + maskheight + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip2">'+ clippos +'</clipPath></defs></svg></div>'; //\

  //'+disstr+'</div>';
}else if (disord == "both-occlude"){
  var masleft = pos_leftpaper_left + 1 * bordersize;
  //var maslefttop =  pos_rightpaper_top +  1 * bordersize;
  paper.innerHTML = '<div class = "backleft">\
  <img class = "imageleft" src="img/greenbackgrd.png" style = "--imleft_posleft:'+pos_leftpaper_left+'px;  --imleft_postop:'+ pos_leftpaper_top +'px;  width:' + paper_width  + 'px; height:' + paper_size + 'px;">\
  <img class = "clip-svg3" src="img/backgray.png" style = "--mask_posleft:'+ pos_leftpaper_left + 'px; --mask_postop: '+ pos_leftpaper_top +'px; width:'+ graywidth +'px; height:' + grayheight + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip3">'+ gclippos +'</clipPath></defs></svg>\
  <img class = "clip-svg2" src="img/Holz1.jpg" style = "--mask_posleft:'+ masleft + 'px; --mask_postop: '+ mastop +'px; width:'+ maskwidth +'px; height:' + maskheight + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip2">'+ clippos +'</clipPath></defs></svg>\
 <img class = "imageright" src="img/greenbackgrd.png" style = "--imright_posleft:'+pos_rightpaper_left+'px;  width:' + paper_width  + 'px; height:' + paper_size + 'px;">\
  <img class = "clip-svg" src="img/backgray.png" style = "--mask_posleft:'+ pos_rightpaper_left + 'px; --mask_postop: '+ pos_rightpaper_top +'px; width:'+ graywidth +'px; height:' + grayheight + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip">'+ gclippos +'</clipPath></defs></svg>\
  <img class = "clip-svg2" src="img/Holz1.jpg" style = "--mask_posleft:'+ masright + 'px; --mask_postop: '+ mastop +'px; width:'+ maskwidth +'px; height:' + maskheight + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip2">'+ clippos +'</clipPath></defs></svg>\
    '+disstr+'</div>';
}else if (disord == "both-no"){
  var masleft = pos_leftpaper_left + 1 * bordersize;
  //var maslefttop =  pos_rightpaper_top +  1 * bordersize;
  paper.innerHTML = '<div class = "backleft">\
  <img class = "imageleft" src="img/greenbackgrd.png" style = "--imleft_posleft:'+pos_leftpaper_left+'px;  --imleft_postop:'+ pos_leftpaper_top +'px;  width:' + paper_width  + 'px; height:' + paper_size + 'px;">\
  <img class = "clip-svg3" src="img/backgray.png" style = "--mask_posleft:'+ pos_leftpaper_left + 'px; --mask_postop: '+ pos_leftpaper_top +'px; width:'+ graywidth +'px; height:' + grayheight + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip3">'+ gclippos +'</clipPath></defs></svg>\
  <img class = "imageleft" src="img/Holz1.jpg" style= "--imleft_posleft:'+ pos_leftpaper_left_small +'px; --imleft_postop:'+ pos_leftpaper_top_small +'px; width:' + maskwidth + 'px; height:' + maskheight + 'px;">\
  <img class = "imageright" src="img/greenbackgrd.png" style = "--imright_posleft:'+pos_rightpaper_left+'px;  width:' + paper_width  + 'px; height:' + paper_size + 'px;">\
  <img class = "clip-svg" src="img/backgray.png" style = "--mask_posleft:'+ pos_rightpaper_left + 'px; --mask_postop: '+ pos_rightpaper_top +'px; width:'+ graywidth +'px; height:' + grayheight + 'px;"><svg width="0" height="0"><defs><clipPath id="myClip">'+ gclippos +'</clipPath></defs></svg>\
  <img class = "imageleft" src="img/Holz1.jpg" style= "--imleft_posleft:'+ masright +'px; --imleft_postop:'+ mastop +'px; width:' + maskwidth + 'px; height:' + maskheight + 'px;">\
    '+disstr+'</div>';
}




//



        /* var buttons = [];
         if (Array.isArray(trial.button_html)) {
           if (trial.button_html.length == trial.choices.length) {
             buttons = trial.button_html;
           } else {
             console.error('Error in html-button-response plugin. The length of the button_html array does not equal the length of the choices array');
           }
         } else {
           for (var i = 0; i < trial.choices.length; i++) {
             buttons.push(trial.button_html);
           }
         }
         paper.innerHTML += '<div id="jspsych-html-button-response-btngroup">';
         for (var i = 0; i < trial.choices.length; i++) {
           var str = buttons[i].replace(/%choice%/g, trial.choices[i]);
             paper.innerHTML += '<div class="jspsych-html-button-response-button"  style= "position: absolute; top:550px; left:'+paper_size/2+'; display: inline-block" id="jspsych-html-button-response-button-' + i +'" data-choice="'+i+'">'+str+'</div>';
         }
           paper.innerHTML += '</div>';

       display_element.innerHTML += '<div style="display: inline-block; margin:140px 0px" /div>'*/

  var start_time = Date.now();

  // add event listeners to buttons
  // for (var i = 0; i < trial.choices.length; i++) {
  //   display_element.querySelector('#jspsych-html-button-response-button-' + i).addEventListener('click', function(e){
  //     var choice = e.currentTarget.getAttribute('data-choice'); // don't use dataset for jsdom compatibility
  //     after_response(choice);
  //   });
  // }

  // function to handle responses by the subject
  // function after_response(choice) {
  //
  //   // after a valid response, the stimulus will have the CSS class 'responded'
  //   // which can be used to provide visual feedback that a response was recorded
  //   display_element.querySelector('#jspsych-html-button-response-stimulus').className += ' responded';
  //
  //   // disable all the buttons after a response
  //   var btns = document.querySelectorAll('.jspsych-html-button-response-button button');
  //   for(var i=0; i<btns.length; i++){
  //     //btns[i].removeEventListener('click');
  //     btns[i].setAttribute('disabled', 'disabled');
  //   }
  //   clear_display();
  //     end_trial();
  // };

    if (trial.trial_duration !== null) {
      jsPsych.pluginAPI.setTimeout(function() {
        clear_display();
        end_trial();
      }, trial.trial_duration);
    }


      function clear_display() {
        display_element.innerHTML = '';
      }
    }


    function end_trial() {
      jsPsych.pluginAPI.clearAllTimeouts();

      // data saving

      if (disord == "hybrid-occludleft"){
        var trial_data = {
        set_size_r: trial.set_size,
        set_size: trial.set_size_r,
        //locations: display_locs,
        colours: to_present
         }
      }else{
        var trial_data = {
        set_size: trial.set_size,
        set_size_r: trial.set_size_r,
        //locations: display_locs,
        colours: to_present
      }
      };
      // go to next trial
      jsPsych.finishTrial(trial_data);
    }
  };

  // helper function for determining stimulus locations

  function cosd(num) {
    return Math.cos(num / 180 * Math.PI);
  }

  function sind(num) {
    return Math.sin(num / 180 * Math.PI);
  }

  return plugin;
})();
