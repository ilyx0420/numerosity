/*-------------------------------------------------------*/
/*----------Interface of Occlusion & Numerosity -------- */
/*---------------Version 1 (without rotation)------------*/
/*-------------------- Hui Men ------------------------- */
/*-------------- University of Marburg ----------------- */
/*------------------- 08.11.2021 ------------------------*/


experiment.html: 
- Start the experiment by opening this file using any browser
- Paramenters of the setup can be changed by revising the first part of this file
    - trialduration: duration of each trial, unit: ms, default value: 2000
    - stimulitype: type of stimuli, 0: dot, 1: square
    - repeti_per_case: repititions for each participant (of each condition & display), default value: 10
    - stim_low: minimum number of stimuli to be displayed, default value: 5
    - stim_high: maximum number of stimuli to be displayed, default value: 15

- Information shown to the participant can be changed in the following modules:
    - instructions: instructions shown to the participant
    - p_details: participants are asked to type in their information
    - conclusion: information displayed at the end of the experiment


At the end of the experiment, results will be automatically saved to your local download.